using UnityEngine;

public class MovingWallScript : MonoBehaviour
{
    public float minSpeed = 7f;
    public float maxSpeed = 12f;

    public float minWidth = 2f;
    public float planeWidth = 10f;
    public float startZ = 15f;
    public float endZ = -15f;

    private float speed;

    void Start()
    {
        ResetWall();
    }

    void Update()
    {
        transform.Translate(0f, 0f, -speed * Time.deltaTime, Space.Self);

        if (transform.localPosition.z < endZ)
        {
            ResetWall();
        }
    }

    private void ResetWall()
    {
        speed = Random.Range(minSpeed, maxSpeed);

        float w = Random.Range(minWidth, planeWidth);
        transform.localScale = new Vector3(w, transform.localScale.y, transform.localScale.z);

        float halfWall = w / 2f;
        float halfPlane = planeWidth / 2f;

        float minX = -halfPlane + halfWall;
        float maxX = halfPlane - halfWall;
        float x = Random.Range(minX, maxX);

        transform.localPosition = new Vector3(x, transform.localPosition.y, startZ);
    }
}
