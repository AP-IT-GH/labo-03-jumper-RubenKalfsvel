using UnityEngine;

public class CubeStabilizer : MonoBehaviour
{
    public Transform sphere;
    private Rigidbody sphereRb;

    void Start()
    {
        if (sphere != null)
            sphereRb = sphere.GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (sphereRb == null) return;

        Vector3 movementDirection = new(sphereRb.linearVelocity.x, 0, sphereRb.linearVelocity.z);

        if (movementDirection.magnitude > 0.1f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(movementDirection);
            transform.rotation = Quaternion.Euler(0, targetRotation.eulerAngles.y, 0);
        }
    }
}
