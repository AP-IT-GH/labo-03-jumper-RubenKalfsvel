using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class RollerAgentRays : Agent
{
    Rigidbody rBody;
    public Transform TargetBall;
    public Transform Finish;
    public float forceMultiplier = 0.5f;
    private bool ballFound = false;

    void Start()
    {
        rBody = GetComponent<Rigidbody>();
    }

    public override void OnEpisodeBegin()
    {
        rBody.angularVelocity = Vector3.zero;
        rBody.linearVelocity = Vector3.zero;
        this.transform.localPosition = new Vector3(0, 0.5f, 0);
        RespawnTarget();
        ballFound = false;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(this.transform.localPosition / 5f);

        sensor.AddObservation(rBody.linearVelocity.x);
        sensor.AddObservation(rBody.linearVelocity.z);

        sensor.AddObservation(rBody.angularVelocity.x);
        sensor.AddObservation(rBody.angularVelocity.y);
        sensor.AddObservation(rBody.angularVelocity.z);

        sensor.AddObservation(ballFound ? 1 : 0);
    }

    public override void OnActionReceived(ActionBuffers actionBuffers)
    {
        Vector3 controlSignal = Vector3.zero;
        controlSignal.x = actionBuffers.ContinuousActions[0];
        controlSignal.z = actionBuffers.ContinuousActions[1];
        rBody.AddForce(controlSignal * forceMultiplier);

        if (!ballFound)
        {
            float distanceToTarget = Vector3.Distance(transform.localPosition, TargetBall.localPosition);
            if (distanceToTarget < 1.42f)
            {
                ballFound = true;
                TargetBall.gameObject.SetActive(false);
                AddReward(0.5f);
            }
        }

        if (this.transform.localPosition.y < 0)
        {
            AddReward(-0.2f);
            EndEpisode();
            return;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == Finish.gameObject && ballFound)
        {
            AddReward(0.5f);
            EndEpisode();
        }
    }

    void RespawnTarget()
    {
        TargetBall.localPosition = new Vector3(Random.Range(-3f, 3f), 0.5f, Random.Range(-3f, 3f));
        TargetBall.gameObject.SetActive(true);
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuousActionsOut = actionsOut.ContinuousActions;
        continuousActionsOut[0] = Input.GetAxis("Horizontal");
        continuousActionsOut[1] = Input.GetAxis("Vertical");
    }
}