using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class CubeAgentJump : Agent
{
    public float jumpForce = 2f;
    private Rigidbody rb;
    private bool isGrounded = true;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ;
    }

    public override void OnEpisodeBegin()
    {
        transform.SetLocalPositionAndRotation(new Vector3(0f, 0.5f, -6f), Quaternion.identity);
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        isGrounded = Physics.Raycast(transform.position, Vector3.down, 0.51f);
        sensor.AddObservation(isGrounded ? 1f : 0f);
        sensor.AddObservation(transform.position.y);
    }

    public override void OnActionReceived(ActionBuffers actionBuffers)
    {
        AddReward(0.025f);
        if (actionBuffers.DiscreteActions[0] == 1 && isGrounded)
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        if (this.transform.localPosition.y < 0)
        {
            AddReward(-0.5f);
            EndEpisode();
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discreteActionsOut = actionsOut.DiscreteActions;
        discreteActionsOut[0] = Input.GetKey(KeyCode.Space) ? 1 : 0;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("MovingWall"))
        {
            AddReward(-1f);
            EndEpisode();
        }
    }
}